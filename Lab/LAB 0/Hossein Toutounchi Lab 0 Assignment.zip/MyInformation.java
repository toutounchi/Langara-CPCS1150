public class MyInformation 

//the class name should always be Capitalized

{
    public static void main(String[]args)
    {
        //There are 6 lines so we need 6 lines of println to print everything after compiling

        System.out.println("****************************************************");
        System.out.println("*                                                  *");
        System.out.println("*         Name:Hossein Toutounchi                  *");
        System.out.println("*         Students Number:100406065                *");
        System.out.println("* Courses:CPSC 1150, Math 1171,BUSM 2115, ECON 1221*");
        System.out.println("*                                                  *");
        System.out.println("****************************************************");
        //We make sure we have enetered the stars spaces and double check after compiling that everything looks good
        
    }
}